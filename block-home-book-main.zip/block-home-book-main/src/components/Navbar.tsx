import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Menu, X, User, LogOut } from 'lucide-react';
import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { isAuthenticated, logout, getCurrentUser } from '@/services/authService';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const Navbar = () => {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState<string | null>(null);

  useEffect(() => {
    const checkAuth = () => {
      const authenticated = isAuthenticated();
      setIsLoggedIn(authenticated);
      
      if (authenticated) {
        const user = getCurrentUser();
        setUserName(user?.name || null);
      } else {
        setUserName(null);
      }
    };
    
    checkAuth();
    
    // Listen for storage changes (for when user logs out in another tab)
    window.addEventListener('storage', checkAuth);
    
    return () => {
      window.removeEventListener('storage', checkAuth);
    };
  }, []);
  
  const handleLogout = () => {
    logout();
    setIsLoggedIn(false);
    setUserName(null);
    navigate('/');
  };

  const handleNavigation = (path: string) => {
    // For protected routes, handle redirection if user is not logged in
    if (!isLoggedIn && (path === '/bookings' || path === '/wallet')) {
      // Store intended destination before redirecting to signin
      sessionStorage.setItem('redirectAfterLogin', path);
      navigate('/signin');
    } else {
      navigate(path);
    }
    
    // Close mobile menu if open
    if (isMenuOpen) {
      setIsMenuOpen(false);
    }
  };

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-40">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        {/* Logo */}
        <Link to="/" className="flex items-center space-x-2">
          <div className="h-8 w-8 rounded-full bg-estate-primary flex items-center justify-center">
            <span className="text-white font-bold">RB</span>
          </div>
          <span className="font-bold text-xl text-estate-primary">BlockEstate</span>
        </Link>

        {/* Search on desktop */}
        <div className="hidden md:flex relative max-w-md w-full mx-4">
          <Input 
            type="text" 
            placeholder="Search properties..." 
            className="pr-10 bg-gray-50"
          />
          <Search className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>

        {/* Navigation for desktop */}
        <div className="hidden md:flex items-center space-x-6">
          <Link to="/" className="text-estate-text hover:text-estate-primary transition-colors">
            Home
          </Link>
          <Link to="/properties" className="text-estate-text hover:text-estate-primary transition-colors">
            Properties
          </Link>
          <button 
            onClick={() => handleNavigation('/bookings')} 
            className="text-estate-text hover:text-estate-primary transition-colors"
          >
            My Bookings
          </button>
          <button 
            onClick={() => handleNavigation('/wallet')} 
            className="text-estate-text hover:text-estate-primary transition-colors"
          >
            Wallet
          </button>
          
          {isLoggedIn ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  <span>{userName}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => navigate('/bookings')}>My Bookings</DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate('/wallet')}>Wallet</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                  <LogOut className="h-4 w-4 mr-2" />
                  <span>Sign out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button 
              variant="default" 
              className="bg-estate-primary hover:bg-estate-primary/90"
              onClick={() => navigate('/signin')}
            >
              Sign In
            </Button>
          )}
        </div>

        {/* Mobile menu button */}
        <Button 
          variant="ghost" 
          size="icon" 
          className="md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
      </div>

      {/* Mobile menu */}
      <div 
        className={cn(
          "md:hidden bg-white absolute w-full transition-all duration-300 ease-in-out border-b border-gray-200",
          isMenuOpen ? "max-h-96 py-4" : "max-h-0 overflow-hidden"
        )}
      >
        <div className="container mx-auto px-4 space-y-4">
          {/* Mobile search */}
          <div className="relative">
            <Input 
              type="text" 
              placeholder="Search properties..." 
              className="pr-10 bg-gray-50"
            />
            <Search className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
          
          {/* Mobile navigation links */}
          <div className="flex flex-col space-y-3">
            <button onClick={() => handleNavigation('/')} className="px-2 py-1.5 rounded hover:bg-gray-100 text-left">
              Home
            </button>
            <button onClick={() => handleNavigation('/properties')} className="px-2 py-1.5 rounded hover:bg-gray-100 text-left">
              Properties
            </button>
            <button onClick={() => handleNavigation('/bookings')} className="px-2 py-1.5 rounded hover:bg-gray-100 text-left">
              My Bookings
            </button>
            <button onClick={() => handleNavigation('/wallet')} className="px-2 py-1.5 rounded hover:bg-gray-100 text-left">
              Wallet
            </button>
            {isLoggedIn ? (
              <Button 
                variant="destructive" 
                onClick={handleLogout} 
                className="mt-2"
              >
                Sign Out
              </Button>
            ) : (
              <Button 
                variant="default" 
                className="bg-estate-primary hover:bg-estate-primary/90 mt-2"
                onClick={() => navigate('/signin')}
              >
                Sign In
              </Button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
