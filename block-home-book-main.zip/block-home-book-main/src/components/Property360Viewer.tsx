
import React, { useEffect, useRef } from 'react';
import { Loader2 } from 'lucide-react';
import * as THREE from 'three';
import { Button } from './ui/button';

interface Property360ViewerProps {
  imageUrl: string;
  onClose?: () => void;
  isFullscreen?: boolean;
}

const Property360Viewer: React.FC<Property360ViewerProps> = ({
  imageUrl,
  onClose,
  isFullscreen = false
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Set loading state
    setLoading(true);
    setError(null);

    let camera: THREE.PerspectiveCamera;
    let scene: THREE.Scene;
    let renderer: THREE.WebGLRenderer;
    let isUserInteracting = false;
    let onPointerDownMouseX = 0;
    let onPointerDownMouseY = 0;
    let lon = 0;
    let onPointerDownLon = 0;
    let lat = 0;
    let onPointerDownLat = 0;
    let phi = 0;
    let theta = 0;

    const init = () => {
      const container = containerRef.current;
      if (!container) return;

      // Calculate dimensions based on container
      const width = container.clientWidth;
      const height = container.clientHeight;

      camera = new THREE.PerspectiveCamera(75, width / height, 1, 1100);
      scene = new THREE.Scene();

      const geometry = new THREE.SphereGeometry(500, 60, 40);
      // invert the geometry on the x-axis so that all of the faces point inward
      geometry.scale(-1, 1, 1);

      const texture = new THREE.TextureLoader();
      texture.load(
        imageUrl,
        (loadedTexture) => {
          const material = new THREE.MeshBasicMaterial({ map: loadedTexture });
          const mesh = new THREE.Mesh(geometry, material);
          scene.add(mesh);
          setLoading(false);
        },
        undefined,
        (err) => {
          console.error('An error occurred loading the 360 image', err);
          setError('Failed to load 360° image');
          setLoading(false);
        }
      );

      renderer = new THREE.WebGLRenderer();
      renderer.setPixelRatio(window.devicePixelRatio);
      renderer.setSize(width, height);
      container.appendChild(renderer.domElement);

      // Add event listeners for mouse/touch interaction
      container.addEventListener('mousedown', onPointerDown);
      container.addEventListener('mousemove', onPointerMove);
      container.addEventListener('mouseup', onPointerUp);
      container.addEventListener('wheel', onDocumentMouseWheel);

      container.addEventListener('touchstart', onPointerDown);
      container.addEventListener('touchmove', onPointerMove);
      container.addEventListener('touchend', onPointerUp);

      window.addEventListener('resize', onWindowResize);
    };

    const onWindowResize = () => {
      if (containerRef.current && camera && renderer) {
        const width = containerRef.current.clientWidth;
        const height = containerRef.current.clientHeight;
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
        renderer.setSize(width, height);
      }
    };

    const onPointerDown = (event: MouseEvent | TouchEvent) => {
      if (!containerRef.current) return;
      
      isUserInteracting = true;

      const clientX = 'touches' in event 
        ? event.touches[0].clientX
        : event.clientX;
      
      const clientY = 'touches' in event
        ? event.touches[0].clientY
        : event.clientY;

      onPointerDownMouseX = clientX;
      onPointerDownMouseY = clientY;
      onPointerDownLon = lon;
      onPointerDownLat = lat;

      event.preventDefault();
    };

    const onPointerMove = (event: MouseEvent | TouchEvent) => {
      if (!isUserInteracting) return;

      const clientX = 'touches' in event 
        ? event.touches[0].clientX
        : event.clientX;
      
      const clientY = 'touches' in event
        ? event.touches[0].clientY
        : event.clientY;

      lon = (onPointerDownMouseX - clientX) * 0.1 + onPointerDownLon;
      lat = (clientY - onPointerDownMouseY) * 0.1 + onPointerDownLat;

      event.preventDefault();
    };

    const onPointerUp = () => {
      isUserInteracting = false;
    };

    const onDocumentMouseWheel = (event: WheelEvent) => {
      // Improve the zoom functionality with better constraints and sensitivity
      const minFov = 30;  // More zoomed in
      const maxFov = 90;  // More zoomed out
      const zoomSensitivity = 0.05;
      
      let newFov = camera.fov + event.deltaY * zoomSensitivity;
      newFov = Math.max(minFov, Math.min(maxFov, newFov));
      
      camera.fov = newFov;
      camera.updateProjectionMatrix();
      
      // Prevent default scrolling behavior
      event.preventDefault();
    };

    const animate = () => {
      requestAnimationFrame(animate);
      update();
    };

    const update = () => {
      if (!isUserInteracting) {
        lon += 0.05;
      }

      lat = Math.max(-85, Math.min(85, lat));
      phi = THREE.MathUtils.degToRad(90 - lat);
      theta = THREE.MathUtils.degToRad(lon);

      const x = 500 * Math.sin(phi) * Math.cos(theta);
      const y = 500 * Math.cos(phi);
      const z = 500 * Math.sin(phi) * Math.sin(theta);

      camera.lookAt(x, y, z);
      renderer.render(scene, camera);
    };

    // Initialize and start the animation
    init();
    animate();

    // Cleanup function
    return () => {
      if (containerRef.current && renderer?.domElement) {
        containerRef.current.removeChild(renderer.domElement);
      }
      window.removeEventListener('resize', onWindowResize);
      
      if (containerRef.current) {
        containerRef.current.removeEventListener('mousedown', onPointerDown);
        containerRef.current.removeEventListener('mousemove', onPointerMove);
        containerRef.current.removeEventListener('mouseup', onPointerUp);
        containerRef.current.removeEventListener('wheel', onDocumentMouseWheel);
        containerRef.current.removeEventListener('touchstart', onPointerDown);
        containerRef.current.removeEventListener('touchmove', onPointerMove);
        containerRef.current.removeEventListener('touchend', onPointerUp);
      }

      renderer?.dispose();
    };
  }, [imageUrl]);

  return (
    <div className={`relative ${isFullscreen ? 'fixed inset-0 z-50 bg-black' : 'w-full h-[400px] rounded-lg overflow-hidden'}`}>
      {onClose && isFullscreen && (
        <Button 
          className="absolute top-4 right-4 z-10" 
          onClick={onClose}
          variant="secondary"
        >
          Close
        </Button>
      )}
      
      {/* Add zoom controls */}
      <div className="absolute bottom-4 left-4 z-10 flex space-x-2">
        <Button
          variant="secondary"
          size="sm"
          onClick={() => {
            if (containerRef.current) {
              const event = new WheelEvent('wheel', { deltaY: -100 });
              containerRef.current.dispatchEvent(event);
            }
          }}
        >
          Zoom In
        </Button>
        <Button
          variant="secondary"
          size="sm"
          onClick={() => {
            if (containerRef.current) {
              const event = new WheelEvent('wheel', { deltaY: 100 });
              containerRef.current.dispatchEvent(event);
            }
          }}
        >
          Zoom Out
        </Button>
      </div>
      
      <div 
        ref={containerRef} 
        className="w-full h-full"
      >
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
            <Loader2 className="h-12 w-12 animate-spin text-estate-primary" />
          </div>
        )}
        
        {error && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-100">
            <p className="text-red-500">{error}</p>
            <p className="text-sm text-gray-500 mt-2">Try refreshing the page</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Property360Viewer;
