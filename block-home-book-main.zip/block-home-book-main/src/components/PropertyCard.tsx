
import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Bed, Bath, Square } from 'lucide-react';

export interface PropertyType {
  id: string;
  title: string;
  price: number;
  location: string;
  image: string;
  images360: string[];
  bedrooms: number;
  bathrooms: number;
  area: number;
  type: 'Apartment' | 'House' | 'Villa' | 'Condo';
  availability: boolean;
  owner?: {
    name: string;
    contact: string;
    rating: number;
    properties: number;
  };
}

interface PropertyCardProps {
  property: PropertyType;
}

const PropertyCard: React.FC<PropertyCardProps> = ({ property }) => {
  const { id, title, price, location, image, bedrooms, bathrooms, area, type, availability } = property;

  return (
    <Link to={`/property/${id}`}>
      <Card className="property-card overflow-hidden h-full">
        <div className="relative">
          <img 
            src={image} 
            alt={title} 
            className="h-48 w-full object-cover"
          />
          <Badge 
            variant="secondary" 
            className={`absolute top-2 right-2 ${
              availability ? 'bg-estate-success text-white' : 'bg-gray-500 text-white'
            }`}
          >
            {availability ? 'Available' : 'Booked'}
          </Badge>
          <Badge 
            variant="secondary" 
            className="absolute top-2 left-2 bg-estate-accent text-white"
          >
            {type}
          </Badge>
        </div>
        <CardContent className="pt-4">
          <h3 className="font-semibold text-lg mb-1 line-clamp-1">{title}</h3>
          <div className="flex items-center text-estate-text mb-3">
            <MapPin className="h-4 w-4 mr-1 text-estate-secondary" />
            <span className="text-sm line-clamp-1">{location}</span>
          </div>
          <div className="flex justify-between mt-2 text-estate-text">
            <div className="flex items-center">
              <Bed className="h-4 w-4 mr-1" />
              <span className="text-sm">{bedrooms}</span>
            </div>
            <div className="flex items-center">
              <Bath className="h-4 w-4 mr-1" />
              <span className="text-sm">{bathrooms}</span>
            </div>
            <div className="flex items-center">
              <Square className="h-4 w-4 mr-1" />
              <span className="text-sm">{area} m²</span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="pt-0 flex justify-between items-center">
          <p className="font-bold text-estate-primary text-lg">Ξ{price.toFixed(3)}</p>
          <Badge className="bg-estate-secondary hover:bg-estate-secondary/90">View Details</Badge>
        </CardFooter>
      </Card>
    </Link>
  );
};

export default PropertyCard;
