
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { 
  Card, 
  CardContent, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { ExternalLink, Loader2, Search, AlertTriangle } from 'lucide-react';
import { 
  connectWallet, 
  isWalletConnected, 
  getWalletAddress, 
  getUserTransactions, 
  BookingTransaction 
} from '@/services/blockchain';
import { getPropertyById } from '@/services/propertyData';

const BookingsPage = () => {
  const [walletConnected, setWalletConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [bookings, setBookings] = useState<BookingTransaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkWalletConnection();
  }, []);

  const checkWalletConnection = async () => {
    if (isWalletConnected()) {
      setWalletConnected(true);
      const address = getWalletAddress();
      setWalletAddress(address);
      loadBookings();
    } else {
      setLoading(false);
    }
  };

  const loadBookings = () => {
    try {
      const transactions = getUserTransactions();
      setBookings(transactions);
      setLoading(false);
    } catch (error) {
      console.error('Error loading bookings:', error);
      toast.error('Failed to load bookings');
      setLoading(false);
    }
  };

  const handleConnectWallet = async () => {
    try {
      setLoading(true);
      const address = await connectWallet();
      setWalletConnected(true);
      setWalletAddress(address);
      loadBookings();
      toast.success('Wallet connected successfully!');
    } catch (error) {
      setLoading(false);
      toast.error('Failed to connect wallet');
      console.error(error);
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  const truncateHash = (hash: string) => {
    return `${hash.substring(0, 6)}...${hash.substring(hash.length - 4)}`;
  };

  if (loading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-16 flex justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-estate-primary" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">My Bookings</h1>

        {!walletConnected ? (
          <Card className="mb-8">
            <CardHeader className="pb-2">
              <CardTitle>Connect Your Wallet</CardTitle>
            </CardHeader>
            <CardContent className="pb-2">
              <p className="text-estate-text">
                Please connect your blockchain wallet to view your property bookings and transactions.
              </p>
            </CardContent>
            <CardFooter>
              <Button onClick={handleConnectWallet}>
                Connect Wallet
              </Button>
            </CardFooter>
          </Card>
        ) : (
          <>
            {/* Wallet Info */}
            <Card className="mb-8">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div className="mb-4 md:mb-0">
                    <h2 className="text-lg font-medium mb-1">Connected Wallet</h2>
                    <p className="text-estate-text">{walletAddress}</p>
                  </div>
                  <Button variant="outline" onClick={loadBookings} className="self-start">
                    Refresh Bookings
                  </Button>
                </div>
              </CardContent>
            </Card>

            {bookings.length > 0 ? (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>Your Property Bookings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Property</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Transaction Hash</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {bookings.map(booking => {
                          const property = getPropertyById(booking.propertyId);
                          return (
                            <TableRow key={booking.id}>
                              <TableCell className="whitespace-nowrap">
                                {formatDate(booking.timestamp)}
                              </TableCell>
                              <TableCell className="font-medium">
                                {property ? property.title : 'Unknown Property'}
                              </TableCell>
                              <TableCell>
                                Ξ{booking.amount.toFixed(3)}
                              </TableCell>
                              <TableCell className="whitespace-nowrap">
                                <div className="flex items-center">
                                  {truncateHash(booking.hash)}
                                  <a
                                    href={`https://etherscan.io/tx/${booking.hash}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="ml-1 text-estate-secondary hover:text-estate-primary"
                                  >
                                    <ExternalLink className="h-4 w-4" />
                                  </a>
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge
                                  className={`${
                                    booking.status === 'confirmed'
                                      ? 'bg-estate-success'
                                      : booking.status === 'pending'
                                      ? 'bg-yellow-500'
                                      : 'bg-red-500'
                                  } text-white`}
                                >
                                  {booking.status}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-right">
                                {property && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    asChild
                                  >
                                    <Link to={`/property/${property.id}`}>
                                      View Property
                                    </Link>
                                  </Button>
                                )}
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <div className="flex justify-center mb-4">
                    <Search className="h-12 w-12 text-gray-400" />
                  </div>
                  <h3 className="text-xl font-medium mb-2">No Bookings Found</h3>
                  <p className="text-estate-text mb-6">
                    You haven't made any property bookings yet with this wallet.
                  </p>
                  <Button asChild>
                    <Link to="/properties">Browse Properties</Link>
                  </Button>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>
    </Layout>
  );
};

export default BookingsPage;
