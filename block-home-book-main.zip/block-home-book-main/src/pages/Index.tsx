
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Search, ArrowRight, Shield, Database, Wallet, Clock } from 'lucide-react';
import Layout from '@/components/Layout';
import PropertyCard from '@/components/PropertyCard';
import { getAllProperties } from '@/services/propertyData';

const Index = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const featuredProperties = getAllProperties().slice(0, 3);

  const handleSearch = () => {
    navigate(`/properties?q=${encodeURIComponent(searchQuery)}`);
  };

  return (
    <Layout>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-estate-primary to-estate-secondary text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Find Your Dream Property with Blockchain Security
            </h1>
            <p className="text-lg mb-8 text-gray-200">
              Discover and book properties with the security and transparency of blockchain technology. 
              No intermediaries, no hidden fees.
            </p>
            <div className="relative max-w-xl mx-auto">
              <Input 
                type="text" 
                placeholder="Search by location or property name..." 
                className="pl-4 pr-32 py-6 rounded-lg text-black"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
              <Button 
                className="absolute right-1.5 top-1.5"
                onClick={handleSearch}
              >
                <Search className="h-5 w-5 mr-2" /> Search
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-estate-dark">Featured Properties</h2>
            <Button 
              variant="outline"
              onClick={() => navigate('/properties')}
              className="flex items-center"
            >
              View All <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
          <div className="property-grid">
            {featuredProperties.map(property => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-estate-dark">
            How BlockEstate Works
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="flex justify-center mb-4">
                  <Search className="h-12 w-12 text-estate-secondary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Search Properties</h3>
                <p className="text-estate-text">
                  Browse through our extensive collection of available properties.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="flex justify-center mb-4">
                  <Wallet className="h-12 w-12 text-estate-secondary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Connect Wallet</h3>
                <p className="text-estate-text">
                  Connect your blockchain wallet to enable secure transactions.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="flex justify-center mb-4">
                  <Database className="h-12 w-12 text-estate-secondary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Sign Contract</h3>
                <p className="text-estate-text">
                  Securely sign the smart contract to book your property.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="flex justify-center mb-4">
                  <Shield className="h-12 w-12 text-estate-secondary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Confirm Booking</h3>
                <p className="text-estate-text">
                  Complete your blockchain transaction and receive booking confirmation.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <Button size="lg" asChild>
              <Link to="/how-it-works">
                Learn More About Our Process
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-estate-light">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-estate-dark">
            The BlockEstate Advantage
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="feature-icon mx-auto mb-4 inline-flex">
                <Shield className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Secure Transactions</h3>
              <p className="text-estate-text">
                All property transactions are secured by blockchain technology, ensuring full transparency and protection.
              </p>
            </div>

            <div className="text-center p-6">
              <div className="feature-icon mx-auto mb-4 inline-flex">
                <Database className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Smart Contracts</h3>
              <p className="text-estate-text">
                Automated smart contracts eliminate intermediaries and reduce costs while increasing security.
              </p>
            </div>

            <div className="text-center p-6">
              <div className="feature-icon mx-auto mb-4 inline-flex">
                <Clock className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Instant Confirmation</h3>
              <p className="text-estate-text">
                Receive instant booking confirmations once your blockchain transaction is processed.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-estate-primary py-16 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Book Your Property?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Experience the future of real estate bookings with blockchain security and transparency.
          </p>
          <Button 
            size="lg" 
            variant="secondary"
            onClick={() => navigate('/properties')}
          >
            Browse Properties
          </Button>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
