
import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import Layout from '@/components/Layout';
import PropertyCard from '@/components/PropertyCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Search, Filter, X } from 'lucide-react';
import { PropertyType } from '@/components/PropertyCard';
import { getAllProperties, searchProperties, getPropertiesByType } from '@/services/propertyData';

const PropertiesPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [properties, setProperties] = useState<PropertyType[]>([]);
  const [filteredProperties, setFilteredProperties] = useState<PropertyType[]>([]);
  const [priceRange, setPriceRange] = useState<string>('all');
  const [propertyType, setPropertyType] = useState<string>('all');
  const [showAvailableOnly, setShowAvailableOnly] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  
  // Initial load of properties
  useEffect(() => {
    const allProperties = getAllProperties();
    setProperties(allProperties);
    
    // Apply search if query exists
    if (initialQuery) {
      const results = searchProperties(initialQuery);
      setFilteredProperties(results);
    } else {
      setFilteredProperties(allProperties);
    }
  }, [initialQuery]);
  
  // Handle search
  const handleSearch = () => {
    if (searchQuery.trim() === '') {
      setFilteredProperties(properties);
      setSearchParams({});
    } else {
      const results = searchProperties(searchQuery);
      setFilteredProperties(results);
      setSearchParams({ q: searchQuery });
    }
  };
  
  // Apply filters
  const applyFilters = () => {
    let results = [...properties];
    
    // Filter by property type
    if (propertyType !== 'all') {
      results = results.filter(property => 
        property.type === propertyType
      );
    }
    
    // Filter by price range
    if (priceRange !== 'all') {
      const [min, max] = priceRange.split('-').map(Number);
      results = results.filter(property => 
        property.price >= min && (max ? property.price <= max : true)
      );
    }
    
    // Filter by availability
    if (showAvailableOnly) {
      results = results.filter(property => property.availability);
    }
    
    // Apply search query if exists
    if (searchQuery.trim() !== '') {
      results = results.filter(property => 
        property.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        property.location.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setSearchParams({ q: searchQuery });
    } else {
      setSearchParams({});
    }
    
    setFilteredProperties(results);
  };
  
  // Reset filters
  const resetFilters = () => {
    setSearchQuery('');
    setPriceRange('all');
    setPropertyType('all');
    setShowAvailableOnly(false);
    setFilteredProperties(properties);
    setSearchParams({});
  };
  
  // Handle filter changes
  useEffect(() => {
    applyFilters();
  }, [propertyType, priceRange, showAvailableOnly]);
  
  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Available Properties</h1>
        
        {/* Search and filter bar */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
              <Input
                placeholder="Search by property name or location"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
              <button 
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                onClick={handleSearch}
              >
                <Search className="h-5 w-5" />
              </button>
            </div>
            
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center"
              >
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>
              
              {(priceRange !== 'all' || propertyType !== 'all' || showAvailableOnly) && (
                <Button 
                  variant="ghost" 
                  onClick={resetFilters} 
                  className="flex items-center text-red-500 hover:text-red-700 hover:bg-red-50"
                >
                  <X className="h-4 w-4 mr-2" />
                  Clear
                </Button>
              )}
            </div>
          </div>
          
          {/* Filter panel */}
          {showFilters && (
            <div className="mt-4 p-4 border rounded-md bg-white">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="property-type">Property Type</Label>
                  <Select 
                    value={propertyType} 
                    onValueChange={setPropertyType}
                  >
                    <SelectTrigger id="property-type">
                      <SelectValue placeholder="All Types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="Apartment">Apartment</SelectItem>
                      <SelectItem value="House">House</SelectItem>
                      <SelectItem value="Villa">Villa</SelectItem>
                      <SelectItem value="Condo">Condo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="price-range">Price Range (ETH)</Label>
                  <Select 
                    value={priceRange} 
                    onValueChange={setPriceRange}
                  >
                    <SelectTrigger id="price-range">
                      <SelectValue placeholder="All Prices" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Prices</SelectItem>
                      <SelectItem value="0-1">0 - 1 ETH</SelectItem>
                      <SelectItem value="1-2">1 - 2 ETH</SelectItem>
                      <SelectItem value="2-3">2 - 3 ETH</SelectItem>
                      <SelectItem value="3">3+ ETH</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="available-only" 
                    checked={showAvailableOnly} 
                    onCheckedChange={(checked) => 
                      setShowAvailableOnly(checked === true)
                    }
                  />
                  <Label htmlFor="available-only">Show available properties only</Label>
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* Results count */}
        <p className="mb-4 text-gray-600">
          Showing {filteredProperties.length} properties
        </p>
        
        {/* Property listings */}
        {filteredProperties.length > 0 ? (
          <div className="property-grid">
            {filteredProperties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <h3 className="text-xl font-medium mb-2">No properties found</h3>
            <p className="text-gray-600 mb-4">
              Try adjusting your search or filter criteria
            </p>
            <Button onClick={resetFilters}>Reset Filters</Button>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default PropertiesPage;
