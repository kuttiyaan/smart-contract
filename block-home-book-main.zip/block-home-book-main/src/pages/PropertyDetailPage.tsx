import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { MapPin, Bed, Bath, Square, Calendar, Tag, Loader2, Check, View, ChevronLeft, ChevronRight, Star, User, Phone } from 'lucide-react';
import { getPropertyById, updatePropertyAvailability, PropertyWithOwner } from '@/services/propertyData';
import { bookProperty, connectWallet, isWalletConnected, getWalletAddress } from '@/services/blockchain';
import Property360Viewer from '@/components/Property360Viewer';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";

const PropertyDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [property, setProperty] = useState<PropertyWithOwner | null>(null);
  const [loading, setLoading] = useState(true);
  const [booking, setBooking] = useState(false);
  const [walletConnected, setWalletConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [showBookingDialog, setShowBookingDialog] = useState(false);
  const [transactionSuccess, setTransactionSuccess] = useState(false);
  const [transactionHash, setTransactionHash] = useState('');
  const [show360View, setShow360View] = useState(false);
  const [showFullscreen360, setShowFullscreen360] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    if (id) {
      const propertyData = getPropertyById(id);
      if (propertyData) {
        setProperty(propertyData);
      } else {
        navigate('/properties');
        toast.error('Property not found');
      }
      setLoading(false);
    }

    // Check if wallet is already connected
    if (isWalletConnected()) {
      setWalletConnected(true);
      setWalletAddress(getWalletAddress());
    }
  }, [id, navigate]);

  const handleConnectWallet = async () => {
    try {
      const address = await connectWallet();
      setWalletConnected(true);
      setWalletAddress(address);
      toast.success('Wallet connected successfully!');
    } catch (error) {
      toast.error('Failed to connect wallet');
      console.error(error);
    }
  };

  const handleBookProperty = async () => {
    if (!walletConnected) {
      toast.error('Please connect your wallet first');
      return;
    }

    if (!property.availability) {
      toast.error('This property is not available for booking');
      return;
    }

    setShowBookingDialog(true);
  };

  const confirmBooking = async () => {
    try {
      setBooking(true);
      
      // Call blockchain service to book property
      const transaction = await bookProperty(
        property.id, 
        property.price, 
        '0xSellerAddress123456789'
      );
      
      // Update property availability in our local data
      updatePropertyAvailability(property.id, false);
      setProperty({ ...property, availability: false });
      
      setTransactionSuccess(true);
      setTransactionHash(transaction.hash);

      // Don't close dialog yet, show success state
    } catch (error) {
      console.error(error);
      toast.error('Booking failed. Please try again.');
      setBooking(false);
      setShowBookingDialog(false);
    }
  };
  
  const closeDialog = () => {
    setShowBookingDialog(false);
    setBooking(false);
    setTransactionSuccess(false);
    setTransactionHash('');
    
    if (transactionSuccess) {
      // Navigate to bookings page if transaction was successful
      navigate('/bookings');
    }
  };

  const handle360ViewToggle = () => {
    setShow360View(!show360View);
  };

  const openFullscreen360 = () => {
    setShowFullscreen360(true);
  };

  const closeFullscreen360 = () => {
    setShowFullscreen360(false);
  };

  if (loading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-16 flex justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-estate-primary" />
        </div>
      </Layout>
    );
  }

  if (!property) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-16 text-center">
          <h2 className="text-2xl font-bold">Property Not Found</h2>
          <p className="mt-4">The property you're looking for doesn't exist or has been removed.</p>
          <Button className="mt-6" onClick={() => navigate('/properties')}>
            Back to Properties
          </Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main content */}
          <div className="lg:col-span-2">
            {/* Property Images */}
            <div className="mb-6 overflow-hidden rounded-lg relative">
              {show360View ? (
                <div className="relative">
                  <Property360Viewer 
                    imageUrl={property.images360[currentImageIndex]} 
                  />
                  <Button 
                    onClick={openFullscreen360}
                    className="absolute bottom-4 right-4 z-10"
                    variant="secondary"
                  >
                    Fullscreen
                  </Button>
                  
                  {/* Image carousel navigation in 360 mode */}
                  <div className="absolute bottom-4 left-4 z-10 flex space-x-2">
                    {property.images360.map((_, index: number) => (
                      <Button
                        key={index}
                        variant={index === currentImageIndex ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCurrentImageIndex(index)}
                      >
                        {index + 1}
                      </Button>
                    ))}
                  </div>
                </div>
              ) : (
                <Carousel className="w-full">
                  <CarouselContent>
                    {property.images360.map((image: string, index: number) => (
                      <CarouselItem key={index} className="relative">
                        <img
                          src={image}
                          alt={`${property.title} view ${index + 1}`}
                          className="w-full h-[400px] object-cover"
                        />
                      </CarouselItem>
                    ))}
                  </CarouselContent>
                  <CarouselPrevious className="left-2 bg-white/80" />
                  <CarouselNext className="right-2 bg-white/80" />
                </Carousel>
              )}
              <Button 
                onClick={handle360ViewToggle}
                className="absolute top-4 right-4"
                variant="secondary"
              >
                {show360View ? 'Standard View' : '360° View'}
              </Button>
            </div>
            
            {/* Property Title and Location */}
            <div className="mb-6">
              <div className="flex flex-wrap gap-2 mb-2">
                <Badge 
                  className={`${
                    property.availability ? 'bg-estate-success' : 'bg-gray-500'
                  } text-white`}
                >
                  {property.availability ? 'Available' : 'Booked'}
                </Badge>
                <Badge className="bg-estate-accent text-white">{property.type}</Badge>
              </div>
              <h1 className="text-3xl font-bold mb-2">{property.title}</h1>
              <div className="flex items-center text-estate-text">
                <MapPin className="h-5 w-5 mr-1 text-estate-secondary" />
                <span>{property.location}</span>
              </div>
            </div>
            
            {/* Property Features */}
            <div className="grid grid-cols-3 gap-4 mb-8">
              <div className="p-4 bg-gray-50 rounded-lg text-center">
                <Bed className="h-6 w-6 mx-auto mb-2 text-estate-secondary" />
                <span className="block text-sm text-gray-500">Bedrooms</span>
                <span className="font-semibold">{property.bedrooms}</span>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg text-center">
                <Bath className="h-6 w-6 mx-auto mb-2 text-estate-secondary" />
                <span className="block text-sm text-gray-500">Bathrooms</span>
                <span className="font-semibold">{property.bathrooms}</span>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg text-center">
                <Square className="h-6 w-6 mx-auto mb-2 text-estate-secondary" />
                <span className="block text-sm text-gray-500">Area</span>
                <span className="font-semibold">{property.area} m²</span>
              </div>
            </div>
            
            {/* Property Owner Details - NEW SECTION */}
            <div className="mb-8 bg-gray-50 p-6 rounded-lg">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <User className="h-5 w-5 mr-2 text-estate-secondary" />
                Property Owner
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-gray-600 mb-1">Name</p>
                  <p className="font-medium">{property.owner.name}</p>
                </div>
                <div>
                  <p className="text-gray-600 mb-1">Contact</p>
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 mr-1 text-estate-secondary" />
                    <p className="font-medium">{property.owner.contact}</p>
                  </div>
                </div>
                <div>
                  <p className="text-gray-600 mb-1">Rating</p>
                  <div className="flex items-center">
                    <Star className="h-4 w-4 mr-1 text-yellow-500" /> 
                    <span className="font-medium">{property.owner.rating} / 5</span>
                  </div>
                </div>
                <div>
                  <p className="text-gray-600 mb-1">Properties Owned</p>
                  <p className="font-medium">{property.owner.properties} properties</p>
                </div>
              </div>
            </div>
            
            {/* Property Description */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">About this property</h2>
              <p className="text-estate-text">
                This beautiful {property.type.toLowerCase()} offers {property.bedrooms} bedrooms and {property.bathrooms} bathrooms with a total area of {property.area}m². 
                Located in a prime location at {property.location}, this property is perfect for those seeking comfort and convenience.
              </p>
              <p className="text-estate-text mt-4">
                The property features modern amenities, including high-speed internet, a fully equipped kitchen, and stunning city views. 
                The neighborhood offers excellent access to public transportation, shopping centers, and restaurants.
              </p>
            </div>
            
            {/* Features and Amenities */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">Features & Amenities</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="flex items-center">
                  <Check className="h-5 w-5 mr-2 text-green-500" />
                  <span>Air Conditioning</span>
                </div>
                <div className="flex items-center">
                  <Check className="h-5 w-5 mr-2 text-green-500" />
                  <span>Heating</span>
                </div>
                <div className="flex items-center">
                  <Check className="h-5 w-5 mr-2 text-green-500" />
                  <span>Wi-Fi</span>
                </div>
                <div className="flex items-center">
                  <Check className="h-5 w-5 mr-2 text-green-500" />
                  <span>Kitchen</span>
                </div>
                <div className="flex items-center">
                  <Check className="h-5 w-5 mr-2 text-green-500" />
                  <span>TV</span>
                </div>
                <div className="flex items-center">
                  <Check className="h-5 w-5 mr-2 text-green-500" />
                  <span>Parking</span>
                </div>
              </div>
            </div>
            
            {/* Location Information */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">Location</h2>
              <div className="bg-gray-100 h-64 rounded-lg flex items-center justify-center">
                <p className="text-gray-500">Map view of {property.location}</p>
              </div>
            </div>
          </div>
          
          {/* Sidebar - Booking and Price */}
          <div>
            <Card className="sticky top-24">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <span className="text-3xl font-bold text-estate-primary">Ξ{property.price.toFixed(3)}</span>
                    <span className="text-estate-text"> ETH</span>
                  </div>
                  <Badge 
                    className={`${
                      property.availability ? 'bg-estate-success' : 'bg-gray-500'
                    } text-white`}
                  >
                    {property.availability ? 'Available' : 'Booked'}
                  </Badge>
                </div>
                
                <div className="border-t border-b py-4 my-4">
                  <div className="flex items-center mb-4">
                    <Calendar className="h-5 w-5 mr-3 text-estate-secondary" />
                    <div>
                      <span className="block font-semibold">Immediate Booking</span>
                      <span className="text-sm text-estate-text">Available via smart contract</span>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Tag className="h-5 w-5 mr-3 text-estate-secondary" />
                    <div>
                      <span className="block font-semibold">Transparent Pricing</span>
                      <span className="text-sm text-estate-text">No hidden fees</span>
                    </div>
                  </div>
                </div>
                
                {!walletConnected ? (
                  <Button 
                    className="w-full mb-4" 
                    onClick={handleConnectWallet}
                  >
                    Connect Wallet
                  </Button>
                ) : (
                  <>
                    <div className="mb-4 p-3 bg-gray-50 rounded-md">
                      <p className="text-sm text-estate-text mb-1">Connected Wallet:</p>
                      <p className="font-medium truncate">{walletAddress}</p>
                    </div>
                    <Button
                      className="w-full mb-4"
                      onClick={handleBookProperty}
                      disabled={!property.availability}
                    >
                      {property.availability ? 'Book Now' : 'Property Unavailable'}
                    </Button>
                  </>
                )}
                
                <p className="text-sm text-center text-estate-text">
                  Booking this property will require a blockchain transaction
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      
      {/* Booking Confirmation Dialog */}
      <Dialog open={showBookingDialog} onOpenChange={setShowBookingDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {transactionSuccess ? 'Booking Successful!' : 'Confirm Booking'}
            </DialogTitle>
            <DialogDescription>
              {transactionSuccess 
                ? 'Your property has been successfully booked using blockchain technology.' 
                : 'You are about to book this property through a blockchain smart contract.'}
            </DialogDescription>
          </DialogHeader>
          
          {!transactionSuccess ? (
            <>
              <div className="space-y-4 py-4">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Property:</span>
                  <span>{property?.title}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Location:</span>
                  <span>{property?.location}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Price:</span>
                  <span className="text-estate-primary font-bold">Ξ{property?.price.toFixed(3)} ETH</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Wallet:</span>
                  <span className="truncate max-w-[200px]">{walletAddress}</span>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setShowBookingDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={confirmBooking} disabled={booking}>
                  {booking ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    'Confirm & Pay'
                  )}
                </Button>
              </DialogFooter>
            </>
          ) : (
            <>
              <div className="py-6 flex flex-col items-center justify-center">
                <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <Check className="h-8 w-8 text-estate-success" />
                </div>
                <h3 className="text-xl font-medium mb-2">Payment Successfully Processed</h3>
                <p className="text-center text-estate-text mb-4">
                  Your blockchain transaction has been confirmed. You can view the details in your bookings.
                </p>
                <div className="w-full p-3 bg-gray-50 rounded-md">
                  <p className="text-sm text-estate-text mb-1">Transaction Hash:</p>
                  <p className="font-medium text-sm truncate">{transactionHash}</p>
                </div>
              </div>

              <DialogFooter>
                <Button onClick={closeDialog}>
                  View My Bookings
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Fullscreen 360 View */}
      {showFullscreen360 && (
        <Property360Viewer 
          imageUrl={property.images360[currentImageIndex]}
          onClose={closeFullscreen360}
          isFullscreen={true}
        />
      )}
    </Layout>
  );
};

export default PropertyDetailPage;
