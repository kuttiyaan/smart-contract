
import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  AlertTriangle,
  Loader2,
  ExternalLink,
  Copy,
  LogOut,
  Wallet,
  Clock,
  RefreshCcw
} from 'lucide-react';
import {
  connectWallet,
  disconnectWallet,
  getWalletAddress,
  getWalletBalance,
  isWalletConnected,
  getUserTransactions,
} from '@/services/blockchain';

const WalletPage = () => {
  const [connected, setConnected] = useState(false);
  const [address, setAddress] = useState<string | null>(null);
  const [balance, setBalance] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [transactionCount, setTransactionCount] = useState(0);

  useEffect(() => {
    checkWalletConnection();
  }, []);

  const checkWalletConnection = async () => {
    try {
      if (isWalletConnected()) {
        const walletAddress = getWalletAddress();
        setConnected(true);
        setAddress(walletAddress);
        await fetchBalanceAndTransactions();
      } else {
        setConnected(false);
        setAddress(null);
        setBalance(null);
      }
    } catch (error) {
      console.error('Error checking wallet connection:', error);
      toast.error('Failed to check wallet connection');
    } finally {
      setLoading(false);
    }
  };

  const fetchBalanceAndTransactions = async () => {
    try {
      const walletBalance = await getWalletBalance();
      setBalance(walletBalance);
      
      const transactions = getUserTransactions();
      setTransactionCount(transactions.length);
    } catch (error) {
      console.error('Error fetching wallet data:', error);
      toast.error('Failed to fetch wallet data');
    }
  };

  const handleConnectWallet = async () => {
    try {
      setLoading(true);
      await connectWallet();
      checkWalletConnection();
      toast.success('Wallet connected successfully!');
    } catch (error) {
      console.error('Error connecting wallet:', error);
      toast.error('Failed to connect wallet');
      setLoading(false);
    }
  };

  const handleDisconnectWallet = () => {
    try {
      disconnectWallet();
      setConnected(false);
      setAddress(null);
      setBalance(null);
      toast.success('Wallet disconnected');
    } catch (error) {
      console.error('Error disconnecting wallet:', error);
      toast.error('Failed to disconnect wallet');
    }
  };

  const handleRefresh = async () => {
    try {
      setRefreshing(true);
      await fetchBalanceAndTransactions();
      toast.success('Wallet data refreshed');
    } catch (error) {
      console.error('Error refreshing wallet data:', error);
      toast.error('Failed to refresh wallet data');
    } finally {
      setRefreshing(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Address copied to clipboard');
  };

  if (loading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-16 flex justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-estate-primary" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Blockchain Wallet</h1>

        {!connected ? (
          <Card className="max-w-md mx-auto">
            <CardHeader className="text-center">
              <CardTitle>Connect Your Blockchain Wallet</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-center">
              <Wallet className="h-16 w-16 mx-auto text-estate-primary" />
              <p className="text-estate-text">
                Connect your blockchain wallet to book properties using smart contracts.
                This allows for secure, transparent transactions on the blockchain.
              </p>
              <Button onClick={handleConnectWallet} className="w-full">
                Connect Wallet
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Wallet Details</CardTitle>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={handleRefresh} 
                      disabled={refreshing}
                    >
                      {refreshing ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <RefreshCcw className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {/* Wallet Address */}
                    <div>
                      <h3 className="text-sm font-medium text-gray-500 mb-1">Wallet Address</h3>
                      <div className="flex items-center gap-2">
                        <div className="bg-gray-100 p-3 rounded-md flex-grow text-sm font-mono">
                          {address}
                        </div>
                        <Button 
                          variant="outline" 
                          size="icon" 
                          onClick={() => address && copyToClipboard(address)}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          asChild
                        >
                          <a 
                            href={`https://etherscan.io/address/${address}`} 
                            target="_blank" 
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </Button>
                      </div>
                    </div>

                    {/* Wallet Balance */}
                    <div>
                      <h3 className="text-sm font-medium text-gray-500 mb-1">Wallet Balance</h3>
                      <div className="bg-gray-100 p-3 rounded-md">
                        <div className="flex items-baseline">
                          <span className="text-2xl font-bold text-estate-primary">
                            {balance !== null ? balance.toFixed(3) : '0.000'}
                          </span>
                          <span className="ml-1 text-estate-text">ETH</span>
                        </div>
                      </div>
                    </div>

                    {/* Transaction Information */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-gray-100 p-4 rounded-md">
                        <div className="flex items-center gap-3">
                          <Clock className="h-5 w-5 text-estate-secondary" />
                          <div>
                            <h4 className="text-sm font-medium">Transactions</h4>
                            <p className="text-2xl font-semibold">{transactionCount}</p>
                          </div>
                        </div>
                      </div>
                      
                      <Button 
                        className="h-full" 
                        variant="outline" 
                        onClick={handleDisconnectWallet}
                      >
                        <LogOut className="h-5 w-5 mr-2" />
                        Disconnect Wallet
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Security Notice</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-start gap-3 mb-4">
                    <div className="mt-1">
                      <AlertTriangle className="h-5 w-5 text-yellow-500" />
                    </div>
                    <p className="text-sm text-estate-text">
                      Never share your private keys or seed phrase with anyone. Be cautious of phishing attempts.
                    </p>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="mt-1">
                      <AlertTriangle className="h-5 w-5 text-yellow-500" />
                    </div>
                    <p className="text-sm text-estate-text">
                      Verify all transaction details before confirming. Blockchain transactions cannot be reversed.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default WalletPage;
