
// Simple authentication service for demo purposes
// In a real-world application, this would be integrated with a backend

interface User {
  email: string;
  name: string;
}

let currentUser: User | null = null;

// Check if user is logged in
export const isAuthenticated = (): boolean => {
  return !!currentUser || !!localStorage.getItem('blockEstate_user');
};

// Get current user
export const getCurrentUser = (): User | null => {
  if (currentUser) return currentUser;
  
  const storedUser = localStorage.getItem('blockEstate_user');
  if (storedUser) {
    try {
      currentUser = JSON.parse(storedUser);
      return currentUser;
    } catch (error) {
      // Handle invalid JSON in localStorage
      localStorage.removeItem('blockEstate_user');
      return null;
    }
  }
  
  return null;
};

// Login function
export const login = (email: string, password: string): Promise<User> => {
  return new Promise((resolve, reject) => {
    // Simple validation
    if (!email || !password) {
      reject(new Error('Email and password are required'));
      return;
    }
    
    if (password.length < 6) {
      reject(new Error('Password must be at least 6 characters'));
      return;
    }
    
    // In a real app, this would be a server call
    // For demo purposes, we'll just simulate a successful login
    setTimeout(() => {
      const user = {
        email,
        name: email.split('@')[0]
      };
      
      currentUser = user;
      localStorage.setItem('blockEstate_user', JSON.stringify(user));
      resolve(user);
    }, 1000);
  });
};

// Logout function
export const logout = (): void => {
  currentUser = null;
  localStorage.removeItem('blockEstate_user');
  // Also clear any redirect information
  sessionStorage.removeItem('redirectAfterLogin');
};

// Get the redirect path after login
export const getRedirectPath = (): string => {
  return sessionStorage.getItem('redirectAfterLogin') || '/';
}

// Clear the redirect path
export const clearRedirectPath = (): void => {
  sessionStorage.removeItem('redirectAfterLogin');
}
