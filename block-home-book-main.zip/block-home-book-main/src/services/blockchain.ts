
// This is a simplified blockchain service for demonstration
// In a real app, you would integrate with actual blockchain libraries like ethers.js or web3.js

import { toast } from 'sonner';

export interface BookingTransaction {
  id: string;
  propertyId: string;
  buyerAddress: string;
  sellerAddress: string;
  amount: number;
  timestamp: number;
  status: 'pending' | 'confirmed' | 'failed';
  hash: string;
}

// Simulated wallet connection
let connectedWallet: string | null = null;
let balance = 15; // ETH

// Sample blockchain transactions
const transactions: BookingTransaction[] = [];

// Connect to wallet
export const connectWallet = async (): Promise<string> => {
  // Simulate wallet connection delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // In a real app, this would connect to MetaMask or another wallet provider
  const mockAddress = `0x${Math.random().toString(16).slice(2, 12)}`;
  connectedWallet = mockAddress;
  
  return mockAddress;
};

// Check if wallet is connected
export const isWalletConnected = (): boolean => {
  return !!connectedWallet;
};

// Get connected wallet address
export const getWalletAddress = (): string | null => {
  return connectedWallet;
};

// Get wallet balance
export const getWalletBalance = async (): Promise<number> => {
  if (!connectedWallet) throw new Error('Wallet not connected');
  return balance;
};

// Book property using smart contract
export const bookProperty = async (
  propertyId: string,
  propertyPrice: number,
  sellerAddress: string
): Promise<BookingTransaction> => {
  if (!connectedWallet) throw new Error('Wallet not connected');
  
  // Check if user has enough balance
  if (balance < propertyPrice) {
    throw new Error('Insufficient balance');
  }
  
  // Simulate blockchain transaction delay
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Deduct balance
  balance -= propertyPrice;
  
  // Create transaction record
  const transaction: BookingTransaction = {
    id: `tx-${Date.now()}`,
    propertyId,
    buyerAddress: connectedWallet,
    sellerAddress,
    amount: propertyPrice,
    timestamp: Date.now(),
    status: 'confirmed',
    hash: `0x${Math.random().toString(16).slice(2, 42)}`
  };
  
  // Add to transactions
  transactions.push(transaction);

  // Show success toast
  toast.success('Property booked successfully!', {
    description: `Transaction hash: ${transaction.hash.slice(0, 10)}...`,
    duration: 5000,
  });
  
  return transaction;
};

// Get transaction by ID
export const getTransaction = (id: string): BookingTransaction | undefined => {
  return transactions.find(tx => tx.id === id);
};

// Get all transactions for current wallet
export const getUserTransactions = (): BookingTransaction[] => {
  if (!connectedWallet) return [];
  return transactions.filter(tx => tx.buyerAddress === connectedWallet);
};

// Disconnect wallet
export const disconnectWallet = (): void => {
  connectedWallet = null;
};
