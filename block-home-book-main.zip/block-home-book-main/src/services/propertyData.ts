
import { PropertyType } from '@/components/PropertyCard';

// Updated property type with owner information
export interface PropertyWithOwner extends PropertyType {
  owner: {
    name: string;
    contact: string;
    rating: number;
    properties: number;
  };
}

// Sample property data
export const properties: PropertyWithOwner[] = [
  {
    id: 'prop-001',
    title: 'Modern Downtown Apartment',
    price: 0.75,
    location: '123 Main St, New York, NY',
    image: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688',
    images360: [
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688',
      'https://images.unsplash.com/photo-1483058712412-4245e9b90334',
      'https://images.unsplash.com/photo-1487958449943-2429e8be8625',
      'https://images.unsplash.com/photo-1473177104440-ffee2f376098'
    ],
    bedrooms: 2,
    bathrooms: 1,
    area: 85,
    type: 'Apartment',
    availability: true,
    owner: {
      name: 'Sarah Johnson',
      contact: 'sarah.j@example.com',
      rating: 4.8,
      properties: 5
    }
  },
  {
    id: 'prop-002',
    title: 'Luxury Beach Villa',
    price: 2.25,
    location: '456 Ocean Dr, Miami, FL',
    image: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914',
    images360: [
      'https://images.unsplash.com/photo-1580587771525-78b9dba3b914',
      'https://images.unsplash.com/photo-1505691938895-1758d7feb511',
      'https://images.unsplash.com/photo-1560518883-ce09059eeffa',
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750'
    ],
    bedrooms: 4,
    bathrooms: 3,
    area: 220,
    type: 'Villa',
    availability: true,
    owner: {
      name: 'Michael Roberts',
      contact: 'michael.r@example.com',
      rating: 4.9,
      properties: 8
    }
  },
  {
    id: 'prop-003',
    title: 'Cozy Suburban House',
    price: 1.15,
    location: '789 Maple Ave, Chicago, IL',
    image: 'https://images.unsplash.com/photo-1570129477492-45c003edd2be',
    images360: [
      'https://images.unsplash.com/photo-1570129477492-45c003edd2be',
      'https://images.unsplash.com/photo-1560185893-a55cbc8c57e8',
      'https://images.unsplash.com/photo-1560185007-c5ca9d2c014d',
      'https://images.unsplash.com/photo-1564013799919-ab600027ffc6'
    ],
    bedrooms: 3,
    bathrooms: 2,
    area: 150,
    type: 'House',
    availability: false,
    owner: {
      name: 'Jennifer Davis',
      contact: 'jennifer.d@example.com',
      rating: 4.7,
      properties: 3
    }
  },
  {
    id: 'prop-004',
    title: 'Downtown Penthouse',
    price: 3.5,
    location: '101 Skyline Blvd, San Francisco, CA',
    image: 'https://images.unsplash.com/photo-1493809842364-78817add7ffb',
    images360: [
      'https://images.unsplash.com/photo-1493809842364-78817add7ffb',
      'https://images.unsplash.com/photo-1502005097973-6a7082348e28',
      'https://images.unsplash.com/photo-1560448204-e02f11c3d0c2',
      'https://images.unsplash.com/photo-1600210492486-724fe5c67fb3'
    ],
    bedrooms: 3,
    bathrooms: 2.5,
    area: 175,
    type: 'Condo',
    availability: true,
    owner: {
      name: 'David Wilson',
      contact: 'david.w@example.com',
      rating: 4.9,
      properties: 7
    }
  },
  {
    id: 'prop-005',
    title: 'Charming Country Cottage',
    price: 0.65,
    location: '222 Rural Route, Portland, OR',
    image: 'https://images.unsplash.com/photo-1518780664697-55e3ad937233',
    images360: [
      'https://images.unsplash.com/photo-1518780664697-55e3ad937233',
      'https://images.unsplash.com/photo-1568605114967-8130f3a36994',
      'https://images.unsplash.com/photo-1570129477492-45c003edd2be',
      'https://images.unsplash.com/photo-1523217582562-09d0def993a6'
    ],
    bedrooms: 2,
    bathrooms: 1,
    area: 90,
    type: 'House',
    availability: true,
    owner: {
      name: 'Emily Thompson',
      contact: 'emily.t@example.com',
      rating: 4.6,
      properties: 2
    }
  },
  {
    id: 'prop-006',
    title: 'City Center Loft',
    price: 1.05,
    location: '333 Urban St, Austin, TX',
    image: 'https://images.unsplash.com/photo-1536376072261-38c75010e6c9',
    images360: [
      'https://images.unsplash.com/photo-1536376072261-38c75010e6c9',
      'https://images.unsplash.com/photo-1520106212299-d99c443e4568',
      'https://images.unsplash.com/photo-1590725121839-892b458a74fe',
      'https://images.unsplash.com/photo-1598928506311-c55ded91a20c'
    ],
    bedrooms: 1,
    bathrooms: 1,
    area: 75,
    type: 'Apartment',
    availability: true,
    owner: {
      name: 'Robert Brown',
      contact: 'robert.b@example.com',
      rating: 4.7,
      properties: 4
    }
  },
  {
    id: 'prop-008',
    title: 'Seaside Bungalow',
    price: 1.85,
    location: '890 Coastal Hwy, San Diego, CA',
    image: 'https://images.unsplash.com/photo-1564501049412-61c2a3083791',
    images360: [
      'https://images.unsplash.com/photo-1564501049412-61c2a3083791',
      'https://images.unsplash.com/photo-1523217582562-09d0def993a6',
      'https://images.unsplash.com/photo-1584738766473-61c083514bf4',
      'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf'
    ],
    bedrooms: 3,
    bathrooms: 2,
    area: 120,
    type: 'House',
    availability: true,
    owner: {
      name: 'Thomas Wright',
      contact: 'thomas.w@example.com',
      rating: 4.6,
      properties: 5
    }
  },
  {
    id: 'prop-009',
    title: 'Urban Studio Apartment',
    price: 0.55,
    location: '123 Downtown Ave, Seattle, WA',
    image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267',
    images360: [
      'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267',
      'https://images.unsplash.com/photo-1560185127-6ed189bf02f4',
      'https://images.unsplash.com/photo-1566665797739-1674de7a421a',
      'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e'
    ],
    bedrooms: 1,
    bathrooms: 1,
    area: 55,
    type: 'Apartment',
    availability: true,
    owner: {
      name: 'Jessica Lee',
      contact: 'jessica.l@example.com',
      rating: 4.5,
      properties: 2
    }
  }
];

// Get all properties
export const getAllProperties = (): PropertyWithOwner[] => {
  return properties;
};

// Get property by ID
export const getPropertyById = (id: string): PropertyWithOwner | undefined => {
  return properties.find(property => property.id === id);
};

// Get available properties
export const getAvailableProperties = (): PropertyWithOwner[] => {
  return properties.filter(property => property.availability);
};

// Get properties by type
export const getPropertiesByType = (type: PropertyWithOwner['type']): PropertyWithOwner[] => {
  return properties.filter(property => property.type === type);
};

// Search properties by title or location
export const searchProperties = (query: string): PropertyWithOwner[] => {
  const lowercaseQuery = query.toLowerCase();
  return properties.filter(
    property => 
      property.title.toLowerCase().includes(lowercaseQuery) ||
      property.location.toLowerCase().includes(lowercaseQuery)
  );
};

// Mock function to update property availability after booking
export const updatePropertyAvailability = (id: string, isAvailable: boolean): void => {
  const propertyIndex = properties.findIndex(property => property.id === id);
  if (propertyIndex !== -1) {
    properties[propertyIndex].availability = isAvailable;
  }
};
